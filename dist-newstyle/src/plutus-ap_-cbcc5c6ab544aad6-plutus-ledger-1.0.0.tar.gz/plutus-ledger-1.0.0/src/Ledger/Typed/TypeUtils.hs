module Ledger.Typed.TypeUtils
  {-# DEPRECATED "Use Plutus.Script.Utils.Typed instead" #-}
  ( module Plutus.Script.Utils.Typed,
  )
where

import Plutus.Script.Utils.Typed
