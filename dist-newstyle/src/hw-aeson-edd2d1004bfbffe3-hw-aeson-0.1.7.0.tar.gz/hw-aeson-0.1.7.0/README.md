# hw-aeson

[![Binaries](https://github.com/haskell-works/hw-aeson/actions/workflows/haskell.yml/badge.svg)](https://github.com/haskell-works/hw-aeson/actions/workflows/haskell.yml)
