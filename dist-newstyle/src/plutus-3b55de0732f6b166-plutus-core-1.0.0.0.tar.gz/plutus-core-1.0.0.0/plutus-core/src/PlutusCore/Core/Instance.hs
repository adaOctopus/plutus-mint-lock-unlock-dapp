module PlutusCore.Core.Instance (module Export) where

import PlutusCore.Core.Instance.Eq ()
import PlutusCore.Core.Instance.Pretty ()
import PlutusCore.Core.Instance.Recursive as Export
import PlutusCore.Core.Instance.Scoping ()
