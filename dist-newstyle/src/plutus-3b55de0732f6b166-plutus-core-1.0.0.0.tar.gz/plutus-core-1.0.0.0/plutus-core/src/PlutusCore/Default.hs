module PlutusCore.Default
    ( module Export
    ) where

import PlutusCore.Default.Builtins as Export
import PlutusCore.Default.Universe as Export
